# Sādhana — The Presence Path

A course app for tantric intimacy: presence, breath, and the art of giving.
Built with React + Vite. Progress and journal entries are stored locally in
the browser (localStorage) — nothing leaves the device.

## Run locally

```bash
npm install
npm run dev
```

## Deploy

### Option A — GitHub + Vercel (recommended, auto-deploys on every push)

1. Create a new repo on GitHub (github.com/new), e.g. `sadhana`.
2. From this folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/sadhana.git
   git push -u origin main
   ```
3. Go to vercel.com/new, click **Import** next to the repo.
4. Vercel auto-detects Vite. Click **Deploy**. Done — you'll get a live URL.

### Option B — Vercel CLI (no GitHub needed)

```bash
npm i -g vercel
vercel
```

Follow the prompts; accept the defaults.

### Option C — Drag and drop (fastest, no git)

```bash
npm install
npm run build
```

Then drag the `dist` folder onto vercel.com/new.
